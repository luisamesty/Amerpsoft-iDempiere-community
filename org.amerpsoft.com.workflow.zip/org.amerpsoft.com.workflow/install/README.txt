Installation Procedure

Plugin an Application Directory Steps:
	1. Install Pluglin
	   Plugin creates Packs: 
		‘AMERPSOFT WorkFlows’ (2Pack_1.0.0)
   
